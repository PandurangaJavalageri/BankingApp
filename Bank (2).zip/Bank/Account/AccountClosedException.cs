﻿using System;
using System.Runtime.Serialization;

namespace Account_ns
{
    [Serializable]
    internal class AccountClosedException : Exception
    {
        public AccountClosedException()
        {
        }

        public AccountClosedException(string message) : base(message)
        {
        }

        public AccountClosedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected AccountClosedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}