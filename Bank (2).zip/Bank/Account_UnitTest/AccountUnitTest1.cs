﻿using Account_Project;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Account_UnitTest
{
    [TestClass]
    public class AccountUnitTest1
    { 
    
        [TestMethod]
        public void Deposit_ShouldIncreaseBalance_WhenAccountIsActive()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);

            // Act
            account.Deposit(200);

            // Assert
            Assert.AreEqual(1200, account.Balance);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountClosedException))]
        public void Deposit_ShouldThrowAccountClosedException_WhenAccountIsClosed()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);
            account.MakeInactive();

            // Act
            account.Deposit(200);
        }

        [TestMethod]
        public void Withdraw_ShouldDecreaseBalance_WhenAccountIsActiveAndHasSufficientFunds()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);

            // Act
            account.Withdraw(1234, 200);

            // Assert
            Assert.AreEqual(800, account.Balance);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountClosedException))]
        public void Withdraw_ShouldThrowAccountClosedException_WhenAccountIsClosed()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);
            account.MakeInactive();

            // Act
            account.Withdraw(1234, 200);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidWithdrawalException))]
        public void Withdraw_ShouldThrowInvalidWithdrawalException_WhenIncorrectPIN()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);

            // Act
            account.Withdraw(5678, 200);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidWithdrawalException))]
        public void Withdraw_ShouldThrowInvalidWithdrawalException_WhenInsufficientFunds()
        {
            // Arrange
            var account = new Account(1, "John Doe", 1000, 1234);

            // Act
            account.Withdraw(1234, 1200);
        }

        [TestMethod]
        public void Transfer_ShouldDecreaseSourceAccountBalanceAndIncreaseDestinationAccountBalance_WhenAccountsAreActiveAndHaveSufficientFunds()
        {
            // Arrange
            var sourceAccount = new Account(1, "John Doe", 1000, 1234);
            var destinationAccount = new Account(2, "Jane Doe", 500, 5678);

            // Act
            sourceAccount.Transfer(destinationAccount, 1234, 300);

            // Assert
            Assert.AreEqual(700, sourceAccount.Balance);
            Assert.AreEqual(800, destinationAccount.Balance);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountClosedException))]
        public void Transfer_ShouldThrowAccountClosedException_WhenSourceAccountIsClosed()
        {
            // Arrange
            var sourceAccount = new Account(1, "John Doe", 1000, 1234);
            var destinationAccount = new Account(2, "Jane Doe", 500, 5678);
            sourceAccount.MakeInactive();

            // Act
            sourceAccount.Transfer(destinationAccount, 1234, 300);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountClosedException))]
        public void Transfer_ShouldThrowAccountClosedException_WhenDestinationAccountIsClosed()
        {
            // Arrange
            var sourceAccount = new Account(1, "John Doe", 1000, 1234);
            var destinationAccount = new Account(2, "Jane Doe", 500, 5678);
            destinationAccount.MakeInactive();

            // Act
            sourceAccount.Transfer(destinationAccount, 1234, 300);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidTransferException))]
        public void Transfer_ShouldThrowInvalidTransferException_WhenIncorrectPIN()
        {
            // Arrange
            var sourceAccount = new Account(1, "John Doe", 1000, 1234);
            var destinationAccount = new Account(2, "Jane Doe", 500, 5678);

            // Act
            sourceAccount.Transfer(destinationAccount, 9999, 300);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidTransferException))]
        public void Transfer_ShouldThrowInvalidTransferException_WhenInsufficientFunds()
        {
            // Arrange
            var sourceAccount = new Account(1, "John Doe", 1000, 1234);
            var destinationAccount = new Account(2, "Jane Doe", 500, 5678);

            // Act
            sourceAccount.Transfer(destinationAccount, 1234, 1200);
        }
    }
}
