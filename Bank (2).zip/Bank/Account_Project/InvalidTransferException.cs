﻿using System;
using System.Runtime.Serialization;

namespace Account_Project
{
    [Serializable]
    public class InvalidTransferException : Exception
    {
        public InvalidTransferException()
        {
        }

        public InvalidTransferException(string message) : base(message)
        {
        }

        public InvalidTransferException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidTransferException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}