﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Moq;
using Account_Mgr;
using Account_Project;
using System.Collections.Generic;

namespace Account_Mgr_UnitTestProject
{
    [TestClass]
    public class Account_Mgr_UnitTest
    {
       


        public void OpenAccount_ShouldCreateNewAccount_WhenNameDoesNotExist()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.OpenAccount("John Doe",123);

            // Assert
            Assert.AreEqual(1, accountManager.accounts.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountAlreadyExistsException))]
        public void OpenAccount_ShouldThrowException_WhenNameAlreadyExists()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.OpenAccount("John Doe",123);
            accountManager.OpenAccount("John Doe", 123);
        }

        [TestMethod]
        public void CloseAccount_ShouldSetClosingDate_WhenAccountExists()
        {
            // Arrange
            var accountManager = new AccountManager();
            accountManager.OpenAccount("John Doe", 123);

            // Act
            accountManager.CloseAccount("John Doe");

            // Assert
            Assert.IsNotNull(accountManager.GetAccount("John Doe").ClosingDate);
        }

        [TestMethod]
        [ExpectedException(typeof(AccountNotFoundException))]
        public void CloseAccount_ShouldThrowException_WhenAccountNotFound()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.CloseAccount("John Doe");
        }

        [TestMethod]
        public void Withdraw_ShouldCallAccountWithdraw_WhenAccountExists()
        {
            // Arrange
            var accountManager = new AccountManager();
            accountManager.OpenAccount("John Doe", 123);
            var account = accountManager.GetAccount("John Doe");

            // Act
            accountManager.Withdraw("John Doe", 123, 100);

            // Assert
            Assert.AreEqual(900, account.Balance); // Assuming a starting balance of 0
        }

        [TestMethod]
        [ExpectedException(typeof(AccountNotFoundException))]
        public void Withdraw_ShouldThrowException_WhenAccountNotFound()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.Withdraw("John Doe", 1234, 100);
        }

        // ... (previous test methods)

        [TestMethod]
        public void Transfer_ShouldCallAccountTransfer_WhenAccountsExist()
        {
            // Arrange
            var accountManager = new AccountManager();
            accountManager.OpenAccount("Sender", 123);
            accountManager.OpenAccount("Receiver", 1234);

            var senderAccount = accountManager.GetAccount("Sender");
            var receiverAccount = accountManager.GetAccount("Receiver");

            decimal initialSenderBalance = senderAccount.Balance;
            decimal initialReceiverBalance = receiverAccount.Balance;

            // Act
            accountManager.Transfer("Sender", "Receiver", 123, 200);

            // Assert
            // Verify that the Transfer method was called on the actual sender account
            Assert.AreEqual(initialSenderBalance - 200, senderAccount.Balance);

            // Verify that the Deposit method was called on the actual receiver account
            Assert.AreEqual(initialReceiverBalance + 200, receiverAccount.Balance);
        }


        [TestMethod]
        [ExpectedException(typeof(AccountNotFoundException))]
        public void Transfer_ShouldThrowException_WhenSenderAccountNotFound()
        {
            // Arrange
            var accountManager = new AccountManager();
            accountManager.OpenAccount("Receiver",134);

            // Act
            accountManager.Transfer("Sender", "Receiver", 134, 200);
        }

        // Similar tests for Deposit

        [TestMethod]
        public void Deposit_ShouldCallAccountDeposit_WhenAccountExists()
        {
            // Arrange
            var account = new Account(1, "John Doe", 0, 1234);
            var accountManager = new AccountManager(new List<Account> { account });

            // Act
            accountManager.Deposit("John Doe", 150);

            // Assert
            Assert.AreEqual(150, account.Balance);
        }


        [TestMethod]
        [ExpectedException(typeof(AccountNotFoundException))]
        public void Deposit_ShouldThrowException_WhenAccountNotFound()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.Deposit("John Doe", 150);
        }

        // Additional tests for other methods and error conditions...

        [TestMethod]

        public void GetAccount_ShouldReturnAccount_WhenAccountExists()
        {
            // Arrange
            var accountManager = new AccountManager();
            accountManager.OpenAccount("John Doe", 123);

            // Act
            var retrievedAccount = accountManager.GetAccount("John Doe");

            // Assert
            Assert.IsNotNull(retrievedAccount);
            Assert.AreEqual("John Doe", retrievedAccount.Name); // Add more assertions based on your Account properties
        }


        [TestMethod]
        [ExpectedException(typeof(AccountNotFoundException))]
        public void GetAccount_ShouldThrowException_WhenAccountNotFound()
        {
            // Arrange
            var accountManager = new AccountManager();

            // Act
            accountManager.GetAccount("Nonexistent Account");
        }

        // Additional tests for other methods and error conditions...

        // You can continue adding more test methods for different scenarios and error conditions.


        // Similar tests for Transfer and Deposit methods...

        // Additional tests for other methods and error conditions...

        // You may also want to test the GetAccountByNumber method and other functionalities.
    }


}
